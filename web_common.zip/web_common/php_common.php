<?php
/**
 * 底层功能接口类文件
 * @author		Arthur(ArthurXF@gmail.com)
 * @copyright	(c) 2006 by php100.com
 * @version		$Id$
 * @package		ArthurXF
 */
require_once('smarty.class.php');
require_once('pdodb.class.php');
require_once('check.class.php');
require_once('gdimage.class.php');
require_once('pdo_page.class.php');
require_once('cache.class.php');
require_once('timer.class.php');

//底层可选功能模块数组
$arrGModule = array();
$arrGModule['phpzip'] = 'phpzip.class.php';						//phpzip压缩功能类
$arrGModule['smtp'] = 'smtp.class.php';							//smtp发邮件类
$arrGModule['ubbcode'] = 'ubbcode.class.php';					//ubb功能类
$arrGModule['domxml'] = 'domxml.class.php';						//domxml功能类
$arrGModule['lastRSS'] = 'lastRSS.class.php';					//抓取RSS功能类
$arrGModule['Snoopy'] = 'Snoopy.class.php';						//网络客户端
$arrGModule['hawhaw'] = 'hawhaw/hawhaw.class.php';				//HTML和WML双格式手机浏览类
$arrGModule['chinese'] = 'chinese/chinese.class.php';			//中文编码转换类（繁简转换，utf8-big5等)
$arrGModule['parsecsv'] = 'parsecsv/parsecsv.lib.php';			//操作csv功能类
$arrGModule['qqwry'] = 'qqwry/qqwry.class.php';					//ip查地域功能类
$arrGModule['nusoap'] = 'nusoap/lib/nusoap.php';				//Web Services 工具
$arrGModule['html2doc'] = 'html2doc.class.php';					//html转换doc类
$arrGModule['SharedMemory'] = 'SharedMemory/SharedMemory.php';	//共享内存类
$arrGModule['feed'] = 'feedcreator.class.php';					//RSS feed生成类
$arrGModule['SplitWord'] = 'splitword/splitword.class.php';		//中文分词类
$arrGModule['ExcelReader'] = 'Excel/ExcelReader.class.php';		//Excel读入类
$arrGModule['ExcelWriter'] = 'Excel/ExcelWriter.class.php';		//Excel写入类

class ArthurXF{
	public $arrGPdoDB = array();
	public $arrGSmarty = array();
	public $arrGPopedom = array();
	public $arrGPage = array();
	public $arrGPic = array();
	public $arrGFile = array();
	public $db = null;

	function db(){
		$this->db = $this->connectG();
	}

	/**
	 * 设置数据库的配置参数
	 * @author	肖飞
	 * @param	array $arrGPdoDB    数据库配置参数
	 * @version	2009-3-13
	 * @return  void
	 */
	function setDBG($arrGPdoDB){
		$this->arrGPdoDB = $arrGPdoDB;
		$this->tablename1 = $this->arrGPdoDB['db_tablepre'].$this->arrGPdoDB['db_table1'];
		$this->tablename2 = $this->arrGPdoDB['db_tablepre'].$this->arrGPdoDB['db_table'];
	}

	/**
	 * 数据库连接
	 * @author	肖飞 <ArthurXF@gmail.com>
	 * @return  object
	 */
	function connectG($arrPdoDB = ''){
		try {
			if(empty($arrPdoDB)) $arrPdoDB = $this->arrGPdoDB;
		    $objPdoDB = new PdoDB($arrPdoDB['dsn'],$arrPdoDB['db_user'],$arrPdoDB['db_password'],array(PDO_ATTR_PERSISTENT => $arrPdoDB['PDO_ATTR_PERSISTENT'],MYSQL_ATTR_USE_BUFFERED_QUERY => true));
			$objPdoDB->exec("set names utf8");
		    return $objPdoDB;
		} catch (PDOException $e) {
		    echo 'Connection failed: ' . $e->getMessage();
		}
	}

	/**
	 * 获取db中记录的数目
	 * @author	肖飞
	 * @param	string $table    数据库表名
	 * @param	string $where    查询条件
	 * @version	2007-11-21
	 * @return  array
	 */
	function getRecordsG($table,$where=''){
		try {
			$strSQL = "select count(1) as num from $table ".$where;
			$rs = $this->db->prepare($strSQL);
			$rs->execute();
			if($arrDate = $rs->fetch()){
				return $arrDate['num'];
			}
		} catch (PDOException $e) {
			if($this->arrGPdoDB['PDO_DEBUG']) echo $strSQL."<br><br>";
		    echo 'Failed: ' . $e->getMessage()."<br><br>";
		}
	}

	/**
	 * 获取mysql函数运算返回的结果
	 * @author	肖飞
	 * @param	string $table	数据库表名
	 * @param	string $fun		查询函数
	 * @param	string $where   查询条件
	 * @version	2009-1-25
	 * @return  array
	 */
	function getFuncitonG($table,$fun,$where=''){
		try {
			$strSQL = "select $fun from $table ".$where;
			$rs = $this->db->prepare($strSQL);
			$rs->execute();
			if($arrDate = $rs->fetch()){
				return $arrDate;
			}
		} catch (PDOException $e) {
			if($this->arrGPdoDB['PDO_DEBUG']) echo $strSQL."<br><br>";
		    echo 'Failed: ' . $e->getMessage()."<br><br>";
		}
	}


	/**
	 * 取得数据记录
	 * @author	肖飞
	 * @param	string	$table		表名
	 * @param	array	$arrData    数据记录信息数组
	 * @param	bool		$blComplex			使用优化查询,超大数据量效果明显,小数据不建议使用
	 * @version	2007-11-21
	 * @return  Boolean
	 */
	function selectDataG($table,$where = '',$limit = '',$field = '*',$blFetch = false,$arrData = array(),$blCount = false,$blComplex = false ){
		try {
			if($blCount){
				//$strSQL = "SELECT SQL_CALC_FOUND_ROWS $field from $table $where";		效率低下,在MYSQL版本未改进之前弃用
				$strSQL = "SELECT $field from $table $where $limit";
			}else{
				$strSQL = "SELECT $field from $table $where $limit";
			}
			if($this->arrGPdoDB['PDO_CACHE']) {
				$strCacheName = md5($strSQL);
				$strCacheDir = '';
				for($i=0;$i<=32;$i+=2){
					$strCacheDir .= '/'.$strCacheName[$i].$strCacheName[$i+1];
				}

				$strCacheName = $strCacheDir.'SQL_'.$table.'_'.$strCacheName;
				$strCacheFile = $this->arrGPdoDB['PDO_CACHE_ROOT'].'/'.$strCacheName;
				$objCache = new cache($strCacheFile,$this->arrGPdoDB['PDO_CACHE_LIFETIME']);
				if($this->arrGPdoDB['PDO_CACHE']==1) {
					if($objCache->cache_is_active()) {
						include($strCacheFile);
						if($arr['COUNT_ROWS'] != '' ) $_SESSION['COUNT_ROWS'] = $arr['COUNT_ROWS'];
						else $arr['COUNT_ROWS'] = $_SESSION['COUNT_ROWS'];
						return $arr;
					}
				}
			}
			if($this->arrGPdoDB['PDO_DEBUG']) echo $strSQL."<br><br>";
			$rs = $this->db->prepare($strSQL);
			$rs->execute($arrData);
			if($blFetch) $arr = $rs->fetch();
			else  $arr = $rs->fetchAll();
			$rs = '';
			if($blCount){
					//$strSQL = "SELECT FOUND_ROWS()";		配合SQL_CALC_FOUND_ROWS使用的
					//$strSQL = "SELECT count(DISTINCT id) from $table $where";
					if(!$blComplex){
						$strSQL = "SELECT count(*) as num from $table $where";
						if($this->arrGPdoDB['PDO_DEBUG']) echo $strSQL."<br><br>";
						$rs = $this->db->query($strSQL);
						if(strpos($where,'GROUP') || strpos($where,'group')){
							$arrTemp = $rs->fetchAll();
							$arr['COUNT_ROWS'] = count($arrTemp);
						}else{
							$arrTemp = $rs->fetch();
							$arr['COUNT_ROWS'] = $arrTemp['num'];
						}
					}
					if($arr['COUNT_ROWS'] != '' ) $_SESSION['COUNT_ROWS'] = $arr['COUNT_ROWS'];
					else $arr['COUNT_ROWS'] = $_SESSION['COUNT_ROWS'];

			}
			if(is_object($objCache)) {
				$somecontent = '<?php' . "\n" . '$arr = ' . var_export( $arr, true ) . ';' . "\n" . '?>';
				$objCache->write_file($somecontent);
			}
			return $arr;
		} catch (PDOException $e) {
			if($this->arrGPdoDB['PDO_DEBUG']) echo $strSQL."<br><br>";
		    echo 'Failed: ' . $e->getMessage()."<br><br>";
		}
	}

	/**
	 * 插入数据记录
	 * @author	肖飞
	 * @param	string	$table		表名
	 * @param	array	$arrData    数据记录信息数组
	 * @version	2007-11-21
	 * @return  Boolean
	 */
	function insertDataG($table,$arrData){
		try {
			$strSQL = "INSERT INTO $table (";
			$strSQL .= '`';
			$strSQL .= implode('`,`', array_keys($arrData));
			$strSQL .= '`)';
			$strSQL .= " VALUES ('";
			$strSQL .= implode("','",$arrData);
			$strSQL .= "')";
			if($this->arrGPdoDB['PDO_DEBUG']) echo $strSQL."<br><br>";
			return $this->db->exec($strSQL);
		} catch (PDOException $e) {
			if($this->arrGPdoDB['PDO_DEBUG']) echo $strSQL."<br><br>";
		    echo 'Failed: ' . $e->getMessage()."<br><br>";
		}
	}

	/**
	 * 返回最后插入数据的ID号
	 * @author	肖飞
	 * @version	2009-1-22
	 * @return  int
	 */
	public function lastInsertIdG(){
		 return $this->db->lastInsertId();
	}

	/**
	 * 取得最后插入数据记录的ID
	 * @author	肖飞
	 * @param	string	$table		表名
	 * @version	2007-11-21
	 * @return  Boolean
	 */
	function getLastIDG(){
		try {
			$strSQL = "SELECT LAST_INSERT_ID();";
			$rs = $this->db->query($strSQL);
			$intLastID = $rs->fetchColumn(0);
			return $intLastID;
		} catch (PDOException $e) {
			if($this->arrGPdoDB['PDO_DEBUG']) echo $strSQL."<br><br>";
		    echo 'Failed: ' . $e->getMessage()."<br><br>";
		}
	}

	/**
	 * 修改数据记录
	 * @author	肖飞
	 * @param	string	$table		表名
	 * @param	array	$arrData    数据记录信息数组
	 * @param	string	$where	    SQL语句的where条件
	 * @version	2007-11-21
	 * @return  Boolean
	 */
	function updateDataG($table,$arrData,$where=''){
		try {
			$strSQL = "	UPDATE $table SET ";
			foreach ($arrData as $k => $v) {
				$strSQL .= $k."='" . $v . "',";
			}
			$strSQL = substr($strSQL, 0, -1);
			$strSQL .= $where;
			if($this->arrGPdoDB['PDO_DEBUG']) echo $strSQL."<br><br>";
			return $this->db->exec($strSQL);
		} catch (PDOException $e) {
			if($this->arrGPdoDB['PDO_DEBUG']) echo $strSQL."<br><br>";
		    echo 'Failed: ' . $e->getMessage()."<br><br>";
		}
	}

	/**
	 * 删除数据记录
	 * @author	肖飞
	 * @param	string	$table		表名
	 * @param	string	$where	    SQL语句的where条件
	 * @version	2007-11-21
	 * @return  Boolean
	 */
	function deleteDataG($table,$where){
		try {
			$strSQL = "DELETE FROM $table $where";
			return $this->db->exec($strSQL);
		} catch (PDOException $e) {
			if($this->arrGPdoDB['PDO_DEBUG']) echo $strSQL."<br><br>";
		    echo 'Failed: ' . $e->getMessage()."<br><br>";
		}
	}

	/**
	 * 数据库字段入库前结构处理
	 * @author	肖飞
	 * @param	array	$arrData	提交过来的数据数组
	 * @version	2007-11-21
	 * @return  array
	 */
	function saveTableFieldG($arrData=null){
		$arrDB = $this->arrGPdoDB['db_table_field'];

		$arrDBstb = $arrDB['structon_tb'];

		foreach ($arrData as $key=>$val){
			if(array_key_exists($key,$arrDB)) {
				if($arrData[$key] != ''){
					$arrDB[$key] = $arrData[$key];
				}
				unset($arrData[$key]);
			}else{
				if(!empty($arrDBstb)){
					if(!in_array($key,$arrDBstb)){
						unset($arrData[$key]);
					}
				}
			}
		}
		//$arrDB['structon_tb'] = serialize($arrData);		序列化在2.0升级中弃用

		if (get_magic_quotes_gpc()){
			if(array_key_exists('structon_tb',$this->arrGPdoDB['db_table_field'])) {
				ArthurXF::arrayWhile($arrData);
				$arrDB['structon_tb'] = addslashes(var_export($arrData,true));
			}
		}else if(array_key_exists('structon_tb',$this->arrGPdoDB['db_table_field'])) $arrDB['structon_tb'] = var_export($arrData,true);
		return $arrDB;
	}

	/**
	 * 数据库字段入库前结构数组递归处理
	 * @author	肖飞
	 * @param	array	$arrData	提交过来的数据数组
	 * @version	2008-8-28
	 * @return  array
	 */
	 function arrayWhile(&$arrData){
		 if(is_array($arrData)){
			 foreach($arrData as $k => $v){
				 if(is_array($v)){
					 ArthurXF::arrayWhile($v);
				 }else{
					 $arrData[$k] = stripslashes($v);
				 }
			 }
		 }
	 }

	/**
	 * 数据库字段出库后结构处理
	 * @author	肖飞
	 * @param	array	$arrData	提交过来的数据数组
	 * @version	2009-3-14
	 * @return  array
	 */
	function loadTableFieldG($arrData=null){
		$arrDB = $this->arrGPdoDB['db_table_field'];

		for($i=0;$i<count($arrData);$i++){
			//$arr = unserialize($arrData[$i]['structon_tb']);	反序列化在2.0升级中弃用
			if($arrData[$i]['structon_tb'] !=""){
				$str = "\$arr = ".$arrData[$i]['structon_tb'].";";
				eval($str);
				foreach ($arr as $k => $v){
					/* 检查structon_tb中的值如果key和外面的相同则跳过赋值，也就不覆盖外面的值，目前此功能取消了。
					$back = 0;
					foreach ($arrDB as $key=>$val){
						if($key == $k){
							$back = 1;
							break;
						}
					}
					if($back == 1) continue;
					else $arrData[$i][$k] = $v;
					*/
					$arrData[$i][$k] = $v;
				}
				unset($arrData[$i]['structon_tb']);
			}
		}

		return $arrData;
	}

	/**
	 * 翻页函数
	 * @author	肖飞 <ArthurXF@gmail.com>
	 * @param	int		$records		总记录数
	 * @param	string	$link			翻页链接
	 * @param	int		$link_type		链接类型 0=普通 1=静态优化 2=Wap链接
	 * @param	string	$link_style		链接样式 缺省为1:2:3:6 ,每个数字代表下面样式中的1行
	 * @param	int		$page_size		特定页面记录条数
	 * @return  string
	 */
	function pageG($records,$link=null,$link_type=0,$link_style='1:2:3:6',$page_size=null){
		$objPage = new pdo_page;
	    //翻页参数
		$objPage->records = $records;
	    if(isset($this->arrGPage['page_size']) !== false) $objPage->page_size = $this->arrGPage['page_size'];
	    if(isset($this->arrGPage['link_num']) !== false) $objPage->link_num = $this->arrGPage['link_num'];
	    if(isset($this->arrGPage['page_count']) !== false) $objPage->page_count = $this->arrGPage['page_count'];
	    if(isset($this->arrGPage['pagestring']) !== false) $objPage->pagestring = $this->arrGPage['pagestring'];
	    if(isset($this->arrGPage['page_link']) !== false) $objPage->page_link = $this->arrGPage['page_link'];
	    if(isset($this->arrGPage['page_select']) !== false) $objPage->page_select = $this->arrGPage['page_select'];
	    if(isset($this->arrGPage['page_jump']) !== false) $objPage->page_jump = $this->arrGPage['page_jump'];
		if(isset($this->arrGPage['file_suffix']) !== false) $objPage->file_suffix = $this->arrGPage['file_suffix'];
	    if($page_size!=null) $objPage->page_size = $page_size;

	    //翻页链接显示输出
	    $objPage->set_page();
		if($link_type == 0 ){
			$objPage->page_link1($link);
			$objPage->page_link5($link);
			$objPage->page_link2($link);
		}
		if($link_type == 1 ){
			$objPage->page_link11($link);
			$objPage->page_link55($link);
			$objPage->page_link22($link);
		}
		$strPage = '';
		if($link_type == 0 || $link_type == 1 ){
			$arrTemp = explode(':', $link_style);
			foreach($arrTemp as $v){
				switch($v){
					case 1:
						$strPage .=  '&nbsp;&nbsp;共'.$objPage->records.'个';       //表中记录的总数
					break;
					case 2:
						$strPage .= '&nbsp;&nbsp;页次'.$objPage->page.'/'.$objPage->page_count.'&nbsp;&nbsp;';         //总页数
					break;
					case 3:
						$strPage .= '&nbsp;&nbsp;'.$objPage->pagestring.'&nbsp;&nbsp;';     //'首页'、'上一页'、'下一页'、'尾页'－－链接样式
					break;
					case 4:
						$strPage .=  '<center>'.$objPage->page_link.'</center>';      //[1]、[2]、[3]－－链接样式
					break;
					case 5:
						$strPage .=  '<center>'.$objPage->page_select.'</center>';    //表单翻页样式
					break;
					case 6:
						$strPage .= '&nbsp;&nbsp;页码: '.$objPage->page_jump;
					break;
				}
			}
			return $strPage;
		}

		if($link_type == 2 ){
			$arrGPage['records'] = $objPage->records;
			$arrGPage['page'] = $objPage->page;
			$arrGPage['page_count'] = $objPage->page_count;
			if( (1<=$arrGPage['page']) && ($arrGPage['page']<=$arrGPage['page_count'])){
				if($arrGPage['page'] < $arrGPage['page_count']){
					$arrGPage['pagedown'] = $arrGPage['page']+1;
				}
				if( $arrGPage['page']>1 ){
					$arrGPage['pageup'] = $arrGPage['page']-1;
				}
			}
			$arrGPage['pagenav'] = $arrGPage['page'].'/'.$arrGPage['page_count'].'页 总'.$arrGPage['records'].'条';

			return $arrGPage;
		}
	}


	/**
	 * 验证用户访问权限
	 * @author	肖飞
	 * @param	int $user_id    会员id
	 * @return  boolean
	 */
	function checkPopedomG($user_id,$thisModel = '') {
		if($_SESSION['user_group'] == 3){
			return true;
		}else{
			if(empty($thisModel)) $thisModel = $this->thisModel;
			$table = 'user';
			$where = ' WHERE user_id=?';
			$field = 'user_group,user_popedom';
			$blFetch = true;
			$arrData = array($user_id);
			$arrUserInfo = $this->selectDataG($table,$where,$limit,$field,$blFetch,$arrData);
			if($arrUserInfo['user_group'] == 3){
				return true;
			}
			if($arrUserInfo['user_group'] == 2){
				$arrPopedom = explode(',', $arrUserInfo['user_popedom']);
				if (in_array($thisModel, $arrPopedom)) {
					return true;
				} else {
					return false;
				}
			}else{
				return false;
			}
		}
	}

	/**
	 * smarty输出函数
	 * @author	肖飞 <ArthurXF@gmail.com>
	 * @param	array	$arrMOutput		smarty数组
	 * @return  void
	 */
	function output($arrMOutput = array(),$cache_id=NULL){
		$objSmarty =& new SmartyTpl();
		if(!isset($arrMOutput['template_dir'])) $arrMOutput['template_dir']='';
		$objSmarty->setTemplateDir($this->arrGSmarty['template_dir'].$arrMOutput['template_dir']);
		$objSmarty->setCompileDir($this->arrGSmarty['compile_dir']);
		$objSmarty->setCacheDir($this->arrGSmarty['cache_dir']);
		$objSmarty->plugins_dir = $this->arrGSmarty['plugins_dir'];
		$arrMOutput["smarty_debug"] ='';
		$arrMOutput["smarty_debug"] ? $objSmarty->compile_check = true : "";
		$arrMOutput["smarty_debug"] ? $objSmarty->debugging = true : "";
		$objSmarty->caching = $this->arrGSmarty['caching'];
		if($objSmarty->caching) {
			//$cache_id =  md5($_SERVER["SCRIPT_URL"]);
			if($cache_id == NULL) $cache_id = $_SESSION['langset'].$_SERVER["REQUEST_URI"];
			$objSmarty->cache_lifetime = isset($this->arrGSmarty['cache_lifetime'])?$this->arrGSmarty['cache_lifetime']:3600;
			$objSmarty->cache_modified_check = isset($this->arrGSmarty['cache_modified_check'])?$this->arrGSmarty['cache_modified_check']:false;
		}
		if (!empty($arrMOutput["smarty_assign"])){
				while(list($key,$value) = each($arrMOutput["smarty_assign"])){
					$objSmarty->assign($key,$value);
				}
			}
		if($_SESSION['langset'] == 'zh_tw'){
			$objSmarty->autoload_filters = array('output' => array('langset'));
		}
		$objSmarty->display($arrMOutput["template_file"],$cache_id);
	}

	/**
	 * XML输出函数
	 * @author	肖飞 <ArthurXF@gmail.com>
	 * @param	array	$arrMOutput		XML
	 * @param	bool	$switch			是否生成文件的标示开关
	 * @return  void
	 */
	function outputXML($arrMOutput = array(),$switch=1){
		$objXML = new xml();
		if($switch==1){
			$objXML->createXml($arrMOutput);
		}else{
			$objXML->creatXmlFile($arrMOutput);
		}
	}

	/**
	 * WDDX中文反解函数
	 * flash中wddx编码中文传值给php后中文自动解码，php就无法正常解wddx包，为了正常传输wddx封包中文，则中文必须用[wddx]标签包括，例如[wddx]urlencode(中文)[/wddx]，
	 * 此函数调用了ubbcode，将封包中的中文编码后，正常解包，然后再将数组中编码的中文解码
	 * @author	肖飞
	 * @param	string	$strWDDX    请求wddx字符串
	 * @param	array	$arrKey	    需要中文解码的变量数组
	 * @return  void
	 */
	function WDDXdecode($strWDDX){
		$objUbbcode = new ubbcode();
		$strWDDX = stripslashes(nl2br($strWDDX));
		if(count($objUbbcode->ubbParameter($strWDDX))){
			$arrData = wddx_deserialize($strWDDX);
			$strData = var_export($arrData,true);
			$strData = $objUbbcode->parse($strData);
			//echo $strData;
			eval("\$arrData = $strData;");
		}else{
			$strWDDX = $objUbbcode->parse($strWDDX);
			$arrData = wddx_deserialize($strWDDX);
		}
		return $arrData;
	}


	#################################################################################################

	/**
	 * 取得信息类型列表
	 * @author	肖飞
	 * @param	string $strInfoTypeTitle    信息类型标题
	 * @return  void
	 */
	function getTypeList($where=null,$order=null,$limit=null){
		if($order == null) $order = ' order by type_sort desc,type_id ';
		$strSQL = "SELECT * FROM $this->tablename1 ".$where.$order.$limit;
		if($this->arrGPdoDB['PDO_DEBUG']) echo $strSQL."<br><br>";
		$rs = $this->db->query($strSQL);
		return $rs->fetchall();
	}

	/**
	 * 取得所有叶子节点的信息类型列表
	 * @author	肖飞
	 * @return  array
	 */
	function fetchTypeLeaf() {
		$arrType = $this->getTypeList();
		$arrParent = array();
		foreach ($arrType as $type) {
			$arrParent[] = $type['type_parentid'];
		}
		foreach ($arrType as $k => $type) {
			if (in_array($type['type_id'], $arrParent)) {
				unset($arrType[$k]);
			}
		}
		return $arrType;
	}


	/**
	 * 递归取出某类别的所有子类别
	 * @author	肖飞
	 * @param	int		$parentID    父类型id
	 * @param	array	$arrList	 类别列表数组
	 * @param	array	$arrChild    所有子类别存入此数组
	 * @return  array
	 */
	function fetchAllChildID($parentID, $arrList, &$arrChild=array()) {
		$arrChild['type_id'][] = $parentID;
		foreach ($arrList as $k => $list) {
			if ($list['type_parentid'] == $parentID) {
				array_push($arrChild, $list);
				$this->fetchAllChildID($list['type_id'], $arrList, $arrChild);
			}
		}
		return $arrChild;
	}

	/**
	 * 取得信息类型内容
	 * @author	肖飞
	 * @param	int		$type_id    信息类型ID
	 * @return  array
	 */
	function getTypeInfo($type_id){
		$table = $this->tablename1;
		$where = ' WHERE type_id=?';
		$field = '*';
		$blFetch = true;
		$arrData = array($type_id);
		return $this->selectDataG($table,$where,$limit,$field,$blFetch,$arrData);
	}

	/**
	 * 获取信息列表数据
	 * @author	肖飞
	 * @param	string		$where				信息类型id
	 * @param	string		$order				排序条件
	 * @param	int			$intStartID			信息数据起始ID
	 * @param	int			$intListNum			列表行数
	 * @param	string		$field				查询字段
	 * @param	array		$arrData			预处理数组
	 * @param	bool		$blCount			是否同时回传数据行数
	 * @param	bool		$blComplex			使用优化查询,超大数据量效果明显,小数据不建议使用
	 * @return  array
	 */
	function getInfoList($where='',$order='',$intStartID = 0,$intListNum = 0,$field = '*',$arrData = array(),$blCount = true,$blComplex = false){
		$table = $this->tablename2;
		$limit = '';
		if($blComplex){
			if($where != '') $where .= " and id <= ( SELECT id FROM `$table` $order LIMIT $intStartID, 1 )";
			else $where = " where id <= ( SELECT id FROM `$table` $order LIMIT $intStartID, 1 )";
		}
		if (!empty($order)) {
			$limit .= $order;
		}
		if ($intListNum != 0) $limit .= " LIMIT " . $intStartID .','. $intListNum;

		$blFetch = false;
		if($field === true) {
			unset($this->arrGPdoDB['db_table_field']['structon_tb']);
			$field = implode(',',array_keys($this->arrGPdoDB['db_table_field']));
		}
		$arrData = $this->selectDataG($table,$where,$limit,$field,$blFetch,$arrData,$blCount);
		if(isset($arrData[0]['structon_tb'])) $arrData = $this->loadTableFieldG($arrData);

		return $arrData;
	}

	/**
	 * 获取信息类型从属关系列表数据
	 * @author	肖飞
	 * @param	int $type_id    信息类型id
	 * @return  void
	 */
	function getRoueList($type_id){
		$strSQL = "Select type_roue_id from $this->tablename1 ".
		" Where type_id ='".$type_id."'";
		$rs = $this->db->query($strSQL);
		if($arr = $rs->fetch()){
			$rs = null;
			$strRoueID = $arr['type_roue_id'];
			$arrTypeID = explode(":",$strRoueID);
			foreach ($arrTypeID as $key=>$val){
				$arrRoueList[$key]['type_id'] = $val;
				$arrRoueList[$key]['type_title'] = $this->getTypeTitle($val);
			}
		}
		return $arrRoueList;
	}

	/**
	 * 获取信息类型标题数据
	 * @author	肖飞
	 * @param	int $type_id    信息类型id
	 * @return  void
	 */
	function getTypeTitle($type_id){
		$strSQL = "Select type_title from $this->tablename1 ".
		" Where type_id =".$type_id;
		$rs = $this->db->query($strSQL);
		$arr = $rs->fetch();
		return $arr['type_title'];
	}

	/**
	 * 取得信息内容
	 * @author	肖飞
	 * @param	int $intInfoID    信息ID
	 * @return  void
	 */
	function getInfo($intInfoID,$field = '*',$pass=null,$add=false){
		if($add) $this->updateClicktimes($intInfoID);
		if($pass!=null) $where= " and pass='$pass'";
		else $where="";
		$strSQL = "SELECT * FROM $this->tablename2 ".
		" Where id ='".$intInfoID."'".$where;
		$rs = $this->db->query($strSQL);
		$arrData = $rs->fetchall();
		if(!empty($arrData[0]['structon_tb'])) $arrData = $this->loadTableFieldG($arrData);

		return current($arrData);
	}

	/**
	 * 增加信息阅读次数
	 * @author	肖飞
	 * @param	int $intInfoID    信息ID
	 * @return  void
	 */
	function updateClicktimes($intInfoID){
		$strSQL = "UPDATE $this->tablename2 SET clicktimes = clicktimes+1".
		" Where id =".$intInfoID;
		$rs = $this->db->query($strSQL);
		return void;
	}

	/**
	 * 取得信息阅读次数
	 * @author	肖飞
	 * @param	int $intInfoID    信息ID
	 * @return  void
	 */
	function getClicktimes($intInfoID){
		$this->updateClicktimes($intInfoID);
		$strSQL = "select clicktimes from $this->tablename2 ".
		" Where id =".$intInfoID;
		$rs = $this->db->query($strSQL);
		return $rs->fetch();
	}

	/**
	 * 取得信息记录最大id号+1
	 * @author	肖飞
	 * @param	string $strInfoTypeTitle    信息类型标题
	 * @return  int
	 */
	function getMaxID(){
		$strSQL = "SELECT id FROM $this->tablename2 order by id desc limit 0 ,1";
		$rs = $this->db->query($strSQL);
		$arrDate = $rs->fetch();
		$intInfoID = $arrDate['id']+1;
		return $intInfoID;
	}

	/**
	 * 取得信息类别最大id号+1
	 * @author	肖飞
	 * @return  int
	 */
	function getTypeMaxID(){
		$strSQL = "SELECT type_id FROM $this->tablename1 order by type_id desc limit 0 ,1";
		$rs = $this->db->query($strSQL);
		$arrDate = $rs->fetch();
		$intInfo_id = $arrDate['type_id']+1;
		return $intInfo_id;
	}


	/**
	 * 插入信息类型数据
	 * @author	肖飞
	 * @param	array $arrType    信息类型数组
	 * @return  void
	 */
	function insertType($arrType){
		return $this->insertDataG($this->tablename1,$arrType);
	}

	/**
	 * 修改信息类型数据
	 * @author	肖飞
	 * @param	array $arrType    信息类型数组
	 * @return  void
	 */
	function updateType($arrType){
		$strWhere = " WHERE `type_id` = '$arrType[type_id]'";
		unset($arrType['type_id']);
		return $this->updateDataG($this->tablename1,$arrType,$strWhere);
	}


	/**
	 * 删除信息类型数据
	 * @author	肖飞
	 * @param	string $intTypeID    信息类型id
	 * @return  void
	 */
	function deleteType($intTypeID){
		$strWhere = " where type_id = $intTypeID";
		$arrInfoList = $this->getInfoList($strWhere);
		if($arrInfoList['COUNT_ROWS'] > 0){
			unset($arrInfoList['COUNT_ROWS']);
			foreach ($arrInfoList as $k => $v) {
				$this->deleteInfo($v['type_id']);
			}
		}
		$arrTypeList = $this->getTypeList();
		$arrChild = $this->fetchAllChildID($intTypeID, $arrTypeList);
		$strSQL = "DELETE FROM $this->tablename1 WHERE `type_id` IN (" . implode(',', $arrChild['type_id']) . ")";
		return $this->db->exec($strSQL);
	}

	/**
	 * 插入信息
	 * @author	肖飞
	 * @param	array $arrData    信息数组
	 * @return  void
	 */
	function insertInfo($arrData){
		return $this->insertDataG($this->tablename2,$arrData);
	}

	/**
	 * 修改信息
	 * @author	肖飞
	 * @param	array $arrData    信息数组
	 * @return  void
	 */
	function updateInfo($arrData){
		$strWhere = " WHERE id = '$arrData[id]'";
		unset($arrData['id']);
		return $this->updateDataG($this->tablename2,$arrData,$strWhere);
	}

	/**
	 * 覆盖信息
	 * @author	肖飞
	 * @param	array $arrData    信息数组
	 * @return  void
	 */
	function replaceInfo($arrData){
		$strSQL = "REPLACE INTO $this->tablename2 (";
		$strSQL .= '`';
		$strSQL .= implode('`,`', array_keys($arrData));
		$strSQL .= '`)';
		$strSQL .= " VALUES ('";
		$strSQL .= implode("','",$arrData);
		$strSQL .= "')";
		return $this->db->exec($strSQL);
	}

	/**
	 * 删除信息
	 * @author	肖飞
	 * @param	int $intInfoID    信息id
	 * @return  void
	 */
	function deleteInfo($intInfoID){
		if($arr = $this->getInfo($intInfoID)){
			if(empty($this->arrGPic['FileSavePath'])) check::AlertExit("文件保存路径未提供，请检查配置文件arrGPic[FileSavePath]的参数！",-1);
			if(is_array($arr['photo']) && !empty($arr['photo'])){
				foreach($arr['photo'] as $v){
					if(is_string($v)) {
						@unlink($this->arrGPic['FileSavePath'].$v);
						@unlink($this->arrGPic['FileSavePath'].'s/'.$v);
						@unlink($this->arrGPic['FileSavePath'].'b/'.$v);
					}
					if(is_array($v)){
						@unlink($this->arrGPic['FileSavePath'].$v['photo']);
						@unlink($this->arrGPic['FileSavePath'].'s/'.$v['photo']);
						@unlink($this->arrGPic['FileSavePath'].'b/'.$v['photo']);
					}
				}
			}elseif(is_string($arr['photo'])){
				@unlink($this->arrGPic['FileSavePath'].$arr['photo']);
			}
		}else{
			check::AlertExit("ID号为 $intInfoID 的记录并不存在！",-1);
		}
		$strWhere = " WHERE `id` = $intInfoID";
		return $this->deleteDataG($this->tablename2,$strWhere);
	}

	/**
	 * 删除信息图片
	 * @author	肖飞
	 * @param	int $intInfoID    信息id
	 * @return  void
	 */
	function deleteInfoPic($intInfoID,$blAlert=true){
		if($arr = $this->getInfo($intInfoID)){
			if(empty($this->arrGPic['FileSavePath'])) check::AlertExit("文件保存路径未提供，请检查配置文件arrGPic[FileSavePath]的参数！",-1);
			if(empty($arr['photo'])) check::AlertExit("ID号为 $intInfoID 的记录并无图片！",-1);
			if(is_array($arr['photo']) && !empty($arr['photo'])){
				foreach($arr['photo'] as $v){
					if(is_string($v)) {
						@unlink($this->arrGPic['FileSavePath'].$v);
						@unlink($this->arrGPic['FileSavePath'].'s/'.$v);
						@unlink($this->arrGPic['FileSavePath'].'b/'.$v);
					}
					if(is_array($v)){
						@unlink($this->arrGPic['FileSavePath'].$v['photo']);
						@unlink($this->arrGPic['FileSavePath'].'s/'.$v['photo']);
						@unlink($this->arrGPic['FileSavePath'].'b/'.$v['photo']);
					}
				}
			}elseif(is_string($arr['photo'])){
				@unlink($this->arrGPic['FileSavePath'].$arr['photo']);
			}
		}
		unset($arr['photo']);
		$arrData = $this->saveTableFieldG($arr);
		if($this->updateInfo($arrData)){
			if($blAlert) check::Alert("图片删除成功！");
		}else{
			if($blAlert) check::Alert("图片删除失败！");;
		}
	}

	/**
	 * 提前信息
	 * @author	肖飞
	 * @param	int $intInfoID    信息id
	 * @return  void
	 */
	function moveupInfo($intInfoID){
		$arrData['submit_date'] = date('Y-m-d H:i:s');
		$strWhere = " WHERE `id` = $intInfoID";
		return $this->updateDataG($this->tablename2,$arrData,$strWhere);
	}

	/**
	 * 隐藏/公布信息
	 * @author	肖飞
	 * @param	int $intInfoID    信息id
	 * @return  void
	 */
	function passInfo($intInfoID,$pass){
		$arrData['pass'] = $pass;
		$strWhere = " WHERE `id` = $intInfoID";
		return $this->updateDataG($this->tablename2,$arrData,$strWhere);
	}

	/**
	 * 固顶/解固信息
	 * @author	肖飞
	 * @param	int $intInfoID    信息id
	 * @return  void
	 */
	function topInfo($intInfoID,$topflag){
		$arrData['topflag'] = $topflag;
		$strWhere = " WHERE `id` = $intInfoID";
		return $this->updateDataG($this->tablename2,$arrData,$strWhere);
	}

	/**
	 * 推荐/解除推荐信息
	 * @author	肖飞
	 * @param	int $intInfoID    信息id
	 * @return  void
	 */
	function recommendInfo($intInfoID,$recommendflag){
		$arrData['recommendflag'] = $recommendflag;
		$strWhere = " WHERE `id` = $intInfoID";
		return $this->updateDataG($this->tablename2,$arrData,$strWhere);
	}

	//逻辑功能
	/**
	 * 将类别按父子关系格式输出，并在title前加上缩进
	 * @author	肖飞
	 * @param	int		$root		起始节点
	 * @param	array	$arrList    类型数组
	 * @param	bool	$blSpace	缩进代码
	 * @param	int		$depth		缩进层次
	 * @param	array	$arrReturn	格式完输出数组
	 * @return  array
	 */
	function formatTypeList($root, $arrList,$blSpace=true, &$depth=0, &$arrReturn=array()) {
		foreach ($arrList as $k => $list) {
			if ($list['type_parentid'] == $root) {
				$strSpace = '';
				$arrTemp = explode(':', $list['type_roue_id']);
				$total = count($arrTemp);
				for($i=0;$i<$total;$i++){
					if ($total == 1) break;
					if($blSpace){
						if($i == 0) $strSpace .= '&nbsp;&nbsp;';
						if($arrTemp[$i] == $list['type_id'] ){

							$strSpace .= '├&nbsp;';
						}else{
							if($arrTemp[$i] != $list['type_parentid'])	$strSpace .= '│&nbsp;&nbsp;';
						}
					}
				}
				if($blSpace){
					if($list['initial']) $list['type_title'] = $strSpace .$list['initial'].' '.$list['type_title'];
					else $list['type_title'] = $strSpace . $list['type_title'];
				}
				$arrReturn[] = $list ;
				$depth++;
				$this->formatTypeList($list['type_id'], $arrList,$blSpace, $depth, $arrReturn);
				//print_r($arrReturn);
				$depth--;
			}
		}
		return $arrReturn;
	}

	function formatTypeArray(&$arrData){
		 if(is_array($arrData)){
			 foreach($arrData as $k => &$v){
				 if(isset($v['child'])){
					 $this->formatTypeArrayChild(&$arrData,&$v['child']);
					 //$v['child']['last'] = true;
				 }else{
					 if(substr_count($v['type_roue_id'],':') == 0){
						 foreach($arrData as $k1 => &$v1){
							if($v['type_id'] == $v1['type_parentid']){
								$v['child'] = $v1;
								unset($arrData[$k1]);
								$this->formatTypeArray(&$arrData);
								//break;
							}
						}
					}else{
						$this->formatTypeArrayChild(&$arrData,&$v);
					}
				 }
			 }
		 }
	 }

	function formatTypeArrayChild(&$arrData,&$arr){
		//echo "******************************<br>";
		//print_r($arrData);
		//print_r($arr);
		//echo "******************************<br>";
		if(is_array($arrData)){
			foreach($arrData as $k => &$v){
				if($arr['type_id'] == $v['type_parentid']){
					//$v['type_title'] = '<ul><li>'.$v['type_title'];
					$arr['child'] = $v;
					unset($v['last']);
					unset($arrData[$k]);
					$this->formatTypeArrayChild($arrData,$arr['child']);
					//$arr['child']['last'] = true;
					//$arr['child']['type_title'] .= '</li></ul>';
				}
			}
		}
	 }

	/**
	 * 生成信息类型列表
	 * @author	肖飞
	 * @param	string $strXML    请求xml字符串
	 * @return  void
	 */
	function makeTypeList(){
		if($arrTypeList = $this->getTypeList()){
			// 得到父分类名称
			foreach ($arrTypeList as $k => $types) {
				 $arrTypeList[$k]['type_parent_title'] = '<i>ROOT</i>' ;
				foreach ($arrTypeList as $k1 => $types1) {
					if ($types['type_parentid'] == $types1['type_id']){
						$arrTypeList[$k]['type_parent_title'] = $types1['type_title'] ;
					}
				}
			}
		}
		return $arrTypeList;
	}

	/**
	 * 插入信息类型
	 * @author	肖飞
	 * @param	array	$arrData    提交的数据数组
	 * @return  void
	 */
	function makeInsertType($arrData){
		if ($arrData['type_roue_id'] != 0){
			if(strrchr($arrData['type_roue_id'], ":") == null) $arrData['type_parentid'] = $arrData['type_roue_id'];
			else $arrData['type_parentid'] = substr(strrchr($arrData['type_roue_id'], ":"), 1);
			$arrData['type_roue_id'] .= ':'.$this->getTypeMaxID();
		}else{
			$arrData['type_parentid'] = 0;
			$arrData['type_roue_id'] = $this->getTypeMaxID();
		}

		$this->insertType($arrData);
	}

	/**
	 * 修改信息类型
	 * @author	肖飞
	 * @param	array	$arrData    提交的数据数组
	 * @return  void
	 */
	function makeUpdateType($arrData){
		if ($arrData['type_roue_id'] != 0){
			$arrData['type_parentid'] = substr(strrchr($arrData['type_roue_id'], ":"), 1);
			if($arrData['type_parentid'] == '') $arrData['type_parentid'] = $arrData['type_roue_id'];
			$arrData['type_roue_id'] .= ':'.$arrData['type_id'];
		}else{
			$arrData['type_parentid'] = 0;
			$arrData['type_roue_id'] = $arrData['type_id'];
		}

		$this->updateType($arrData);
	}


	/**
	 * 生成信息列表
	 * @author	肖飞
	 * @param	string		$strWhere			查询条件
	 * @param	int			$intStartID			信息数据起始ID
	 * @param	int			$intListNum			列表行数
	 * @param	string		$order				排序条件
	 * @return  void
	 */
	function makeInfoList($strWhere,$order=null,$intStartID,$intListNum = 20){
		if($arr = $this->getInfoList($strWhere,$order,$intStartID,$intListNum)){
			return $arr;
		}else{
			return false;
		}
	}

	/**
	 * 保存信息内容
	 * @author	肖飞
	 * @param	int $arrData    信息信息数组
	 * @return  void
	 */
	function saveInfo($arrData,$intModify=0,$blAlert=true){
		$arr = array();
		if(!empty($arrData['titleprefix'])) $arrData['title'] = $arrData['titleprefix'].$arrData['longtitle'];
		unset($arrData['titleprefix']);
		unset($arrData['longtitle']);
		//非法信息过滤
		@include_once(__WEB_ROOT.'/data/illegal.inc.php');
		if(!empty($arrGIllegal) && !empty($arrData['intro'])){
			foreach($arrGIllegal as $k => $v){
				if($v['pass'] == 1){
					$arrData['title'] = str_replace($k,$v['replace'],$arrData['title']);
					$arrData['intro'] = str_replace($k,$v['replace'],$arrData['intro']);
					$arrData['summary'] = str_replace($k,$v['replace'],$arrData['summary']);
				}
			}
		}
		//关键词广告
		@include_once(__WEB_ROOT.'/data/keywords.inc.php');
		if(!empty($arrGKeywords) && !empty($arrData['intro'])){
			foreach($arrGKeywords as $k => $v){
				if($v['pass'] == 1){
					$arrData['intro'] = str_replace('<A class=keyad target=_blank href=\"'.$v['url'].'\">'.$k.'</A>',$k,$arrData['intro']);
					$arrData['intro'] = str_replace('<A class=keyad href=\"'.$v['url'].'\" target=_blank>'.$k.'</A>',$k,$arrData['intro']);
					$arrData['intro'] = str_replace($k,"<a class=keyad target=_blank href=$v[url]>$k</a>",$arrData['intro']);
				}
			}
		}
		$arr = check::SqlInjection($this->saveTableFieldG($arrData));


		if($intModify == 0){
			$arr['user_id'] = intval($_SESSION['user_id']);
			if($this->insertInfo($arr)){
				if($blAlert) check::Alert("发布成功");
			}else{
				if($blAlert) check::Alert("发布失败");;
			}
		}
		if($intModify == 1){
			if($this->updateInfo($arr)){
				if($blAlert) check::Alert("修改成功！");
			}else{
				if($blAlert) check::Alert("修改失败");;
			}
		}
		if($intModify == 2){
			if($this->replaceInfo($arr)){
				if($blAlert) check::Alert("发布成功！");
			}else{
				if($blAlert) check::Alert("发布失败");;
			}
		}

	}

	/**
	 * 保存抓取其他网站的内容
	 * @author	肖飞
	 * @param	array $arrData    新闻信息数组
	 * @return  void
	 */
	function saveFetchInfo($arrData){
		//非法信息过滤
		@include_once(__WEB_ROOT.'/data/illegal.inc.php');
		if(!empty($arrGIllegal) && !empty($arrData['intro'])){
			foreach($arrGIllegal as $k => $v){
				if($v['pass'] == 1){
					$arrData['title'] = str_replace($k,$v['replace'],$arrData['title']);
					$arrData['intro'] = str_replace($k,$v['replace'],$arrData['intro']);
				}
			}
		}
		//关键词广告
		@include_once(__WEB_ROOT.'/data/keywords.inc.php');
		if(!empty($arrGKeywords) && !empty($arrData['intro'])){
			foreach($arrGKeywords as $k => $v){
				if($v['pass'] == 1){
					$arrData['intro'] = str_replace($k,'<A href="'.$v[url].'" class=keyad target=_blank>$k</A>',$arrData['intro']);
				}
			}
		}
		$arr = array();
		$arr = check::SqlInjection($this->saveTableFieldG($arrData));

		$arr['user_id'] = intval($_SESSION['user_id']);
		if($this->insertInfo($arr)){
			echo ("<pre><font color=#ff0000>".$arr['title']."</font> 写入成功！</pre>");
		}else{
			echo ("<pre><font color=#ff0000>".$arr['title']."</font> 写入失败！</pre>");
		}

	}

	/**
	 * 上传信息图片
	 * @author	肖飞
	 * @param array	 	$arrFile			图片文件信息数组$_FILES
	 * @param string	$strGSaveFile		全局变量图片保存路径
	 * @param int		$intGFileMaxSize	全局变量上传图片文件大小上限（K）
	 * @param int 		$num				图片的标号（用于多图上传）
	 * @param int 		$PR					原图自动压缩的比例（像素或者例如0.50）
	 * @param int 		$FileListPicSize	缩略图自动压缩的比例(像素）
	 * @param int		$intInfoID			素材内容ID，标示新增还是修改
	 * @param int		$intFetch			是否来自采集
	 * @param bool		$blTime				是否使用时间戳
	 * @param string	$FileExt			文件后缀名
	 * @return unknown
	 */
	function uploadInfoImage($arrFile,$num=null,$FileListPicSize='',$PR=0,$intInfoID=0,$intFetch=0,$blTime=true,$FileExt=''){
		global $arrGCache;
		if ($arrFile['error'] != 0) {
			check::AlertExit("文件上传错误！(".$arrFile['error'].")",-1);
		}
		if ($arrFile['name']) {
			if (!in_array( strtolower($arrFile['type']) , array( 'image/jpg','image/jpeg' , 'image/gif' , 'image/pjpeg','image/x-png','application/x-shockwave-flash'))) {
				check::AlertExit("文件类型不符合要求(".$arrFile['type'].")",-1);
			}
		}

		if($intInfoID == 0)	$intID = $this->getMaxID();
		else $intID = $intInfoID;
		$strDir = ceil($intID/$arrGCache['cache_filenum']);
		if(!is_dir($this->arrGPic['FileSavePath'])){
			@mkdir($this->arrGPic['FileSavePath']);
			@chmod($this->arrGPic['FileSavePath'],0777);
		}
		$strMakeDir = $this->arrGPic['FileSavePath'].'b/';
		if( !is_dir($strMakeDir) ){
			@mkdir ($strMakeDir);
			@chmod ($strMakeDir, 0777);
		}
		$strMakeDir = $strMakeDir.$strDir;
		if( !is_dir($strMakeDir) ){
			@mkdir ($strMakeDir);
			@chmod ($strMakeDir, 0777);
		}

		if($FileExt == '') $FileExt=strtolower(strrchr($arrFile['name'],"."));  //取得上传文件扩展名
		if($blTime) $strTime = time();
		else $strTime = '';
		if(!empty($num)) {
			$strPhoto = $strDir."/".$intID."_".$strTime."_$num".$FileExt;  //存入数据库的图片访问路径
			$strPicName = $strMakeDir."/".$intID."_".$strTime."_$num".$FileExt;  //新图片路径及名称
		}else{
			$strPhoto = $strDir."/".$intID."_".$strTime.$FileExt;
			$strPicName = $strMakeDir."/".$intID."_".$strTime.$FileExt;
		}
		if(!empty($FileListPicSize)){
			//所有的图都生成缩略图
			$strMakeSmallDir = $this->arrGPic['FileSavePath'].'s/';
			if( !is_dir($strMakeSmallDir) ){
				@mkdir ($strMakeSmallDir);
				@chmod ($strMakeSmallDir, 0777);
			}
			$strMakeSmallDir = $strMakeSmallDir.$strDir;
			if( !is_dir($strMakeSmallDir) ){
				@mkdir ($strMakeSmallDir);
				@chmod ($strMakeSmallDir, 0777);
			}
			if(!empty($num)) {
				$strSmallPicName = $strMakeSmallDir."/".$intID."_".$strTime."_$num".$FileExt;
			}else $strSmallPicName = $strMakeSmallDir."/".$intID."_".$strTime.$FileExt;
			copy($arrFile['tmp_name'], $strSmallPicName);
			$objGDImage =& new GDImage();
			if(!$objGDImage->makePRThumb($strSmallPicName,0,$FileListPicSize,$FileListPicSize)){
				check::AlertExit($strSmallPicName."缩略图生成错误！",-1);
			}
		}
		if( $arrFile['size']>$this->arrGPic['FileMaxSize']){
			if($PR != 0){
				move_uploaded_file($arrFile['tmp_name'], $strPicName);
				$objGDImage = &new GDImage();
				if($PR>1){
					if($objGDImage->makePRThumb($strPicName,'',$PR,$PR)){
						return $strPhoto;
					}else{
						check::AlertExit($strPicName."文件上传错误！",-1);
					}
				}else{
					if($objGDImage->makePRThumb($strPicName,$PR)){
						return $strPhoto;
					}else{
						check::AlertExit($strPicName."文件上传错误！",-1);
					}
				}
			}else{
				check::AlertExit("文件大小不符合要求！",-1);
			}
		}else{
			if($intFetch){
				if(copy($arrFile['tmp_name'], $strPicName)){
					return $strPhoto;
				}else{
					echo $strPicName."文件上传错误！";exit;
				}
			}else{
				if(move_uploaded_file($arrFile['tmp_name'], $strPicName)){
					return $strPhoto;
				}else{
					echo $strPicName;
					check::AlertExit($strPicName."文件上传错误！",-1);
				}
			}
		}
	}

	/**
	 * 上传文件
	 * @author	肖飞
	 * @param array	 	$arrFile			图片文件信息数组$_FILES
	 * @param int 		$arrFileExt			允许上传的文件后缀
	 * @param int		$intInfoID			模板内容ID，标示新增还是修改
	 * @return unknown
	 */
	function uploadInfoFile($arrFile,$intInfoID=0,$arrFileExt=array( '.rar','.zip','.doc','.pdf')){
		global $arrGCache;
		$intInfoID=(is_null($intInfoID)?0:$intInfoID);

		if ($arrFile['error'] != 0) {
			check::AlertExit("文件上传错误！(".$arrFile['error'].")",-1);
		}
		if ($arrFile['name']) {
			$strFileExt = strrchr($arrFile['name'],".");
			if (!in_array( strtolower($strFileExt) , $arrFileExt)) {
				check::AlertExit("文件类型不符合要求(".$strFileExt.")",-1);
			}
		}

		if($intInfoID == 0)	$intID = $this->getMaxID();
		else $intID = $intInfoID;
		$strDir = ceil($intID/$arrGCache['cache_filenum']);
		if(!is_dir($this->arrGPic['FileSavePath'])){
			@mkdir($this->arrGPic['FileSavePath']);
			@chmod($this->arrGPic['FileSavePath'],0777);
		}
		$strMakeDir = $this->arrGPic['FileSavePath'].'f/';
		if( !is_dir($strMakeDir) ){
			@mkdir ($strMakeDir);
			@chmod ($strMakeDir, 0777);
		}
		$strMakeDir = $strMakeDir.$strDir;
		if( !is_dir($strMakeDir) ){
			@mkdir ($strMakeDir);
			@chmod ($strMakeDir, 0777);
		}

		$strfile = 'f/'.$strDir."/".$intID."_".time().$strFileExt;  //存入数据库的文件访问路径
		$strFileName = $strMakeDir."/".$intID."_".time().$strFileExt;  //新文件路径及名称

		if(move_uploaded_file($arrFile['tmp_name'], $strFileName)){
			return $strfile;
		}else{
			check::AlertExit($strFileName."文件上传错误！",-1);
		}
	}

	/**
	 * 生成信息列表翻页
	 * @author	肖飞
	 * @param	int		$records		总记录数
	 * @param	string	$link			翻页链接
	 * @param	int		$link_type		链接类型 0=普通 1=静态优化 2=Wap链接
	 * @param	string	$link_style		链接样式 缺省为1:2:3:6 ,每个数字代表下面样式中的1行
	 * @param	int		$page_size		特定页面记录条数
	 * @return  string
	 */
	function makeInfoListPage($records,$link=null,$link_type=0,$link_style='1:2:3:6',$page_size=null){
		return $this->pageG($records,$link,$link_type,$link_style,$page_size);
	}


	/**
	 * 执行信息操作
	 * @author	肖飞
	 * @param	string	$strAction  执行命令
	 * @param	array	$arrData	选中的操作数据id数组
	 * @return  void
	 */
	 function doInfoAction($strAction=null,$arrData=null){
		switch ($strAction){
			case 'del':
				foreach ($arrData as $key=>$val){
					$this->deleteInfo($val);
				}
				break;
			case 'delpic':
				foreach ($arrData as $key=>$val){
					$this->deleteInfoPic($val);
				}
				break;
			case 'moveup':
				foreach ($arrData as $key=>$val){
					$this->moveupInfo($val);
				}
				break;
			case 'check':
				foreach ($arrData as $key=>$val){
					$this->passInfo($val,1);
				}
				break;
			case 'uncheck':
				foreach ($arrData as $key=>$val){
					$this->passInfo($val,0);
				}
				break;
			case 'settop':
				foreach ($arrData as $key=>$val){
					$this->topInfo($val,1);
				}
				break;
			case 'unsettop':
				foreach ($arrData as $key=>$val){
					$this->topInfo($val,0);
				}
				break;
			case 'setrecommend':
				foreach ($arrData as $key=>$val){
					$this->recommendInfo($val,1);
				}
				break;
			case 'unsetrecommend':
				foreach ($arrData as $key=>$val){
					$this->recommendInfo($val,0);
				}
				break;
		}
		return true;
	}

}
?>